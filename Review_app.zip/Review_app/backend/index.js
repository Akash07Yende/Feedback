const express = require('express')


const app = express()

app.get('/home', (req, res)=> {
   const api = [
    {id: 1, name : 'akash' , marks: 33},
    {id: 2, name : 'akshay' , marks: 32}
   ]
    res.send(api)
})

app.listen(9000)