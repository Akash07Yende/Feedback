

// import './App.css';
import { Route, Routes } from 'react-router-dom';
import Contact from './component/Contact';
import SignIn from './component/SignIn';
import SignUp from './component/SignUp';
import Home from './component/Home';
import About from './component/About';
import MyTeam from './component/Team';
import Work from './component/Work';
import AddCompany from './component/AddCompany';

function App() {
  return (
    <div>
      <Routes>
        <Route path='/' element={<Home></Home>}/>
        <Route path='/SignIn' element={<SignIn></SignIn>}/>
        <Route path='/SignUp' element={<SignUp></SignUp>}/>
        <Route path='/About' element={<About></About>}/>
        <Route path='/AddCompany' element={<AddCompany/>}/>
        <Route path='/Contact' element={<Contact></Contact>}/>
        <Route path='/Team' element={<MyTeam></MyTeam>}/>
        <Route path='/Work' element={<Work></Work>}/>
      </Routes>
    </div>
  );
}

export default App;
