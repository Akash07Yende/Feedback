

export function WorkMember ({title, description, imgUrl}) {
  return (
    <div className="col-sm-12 col-md-4 col-lg-4">
        <div className='card proj-imgbx' style={{width: '18rem'}}>
      <img src={imgUrl} className='card-img-top' alt='...' />
      <div className='card-body'>
        <h5 className='card-title'>{title}</h5>
        <p className='card-text'>
          {description}
        </p>
        <a href='#' className='card-link'>Read More</a>
      </div>
    </div>
    </div>
  )
}
