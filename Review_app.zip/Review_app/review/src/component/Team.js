import Navbar from './Navbar'
import member1 from '../assest/img/team-1-2.png'
import member2 from '../assest/img/team-1-3.png'
import member3 from '../assest/img/team-1-4.png'
import member4 from '../assest/img/team-1-5.png'
import { TeamMember } from './TeamMembers'

import emoji from '../assest/img/emoji5.png'

import '../assest/style.css/team.css'

import Footer from './Footer'

function MyTeam () {

  const TeamMembers = [
    {
      title: 'Contribute With Your Opinion',
      description: 'Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
      imgUrl: member1
    },
    {
      title: 'Rate A Product You Have Already Used',
      description: 'Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
      imgUrl: member2
    },
    {
      title: 'Collect Opinions & Get Your Choice Right',
      description: 'Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
      imgUrl: member3
    },
    {
      title: 'Collect Opinions & Get Your Choice Right',
      description: 'Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
      imgUrl: member4
    }
  ]

  return (

    <div className='team'>
      <div className='header'>
        <div>
          <Navbar></Navbar>
        </div>
        <div className='nav-head text-center align-items-center'>
          <div className='star-icon'>
            <img src={emoji} alt='emoji' style={{height:'60px', width:'60px'}}/>
            <h1>Team</h1>
            <p>
              <span>Home -</span> Team
            </p>
          </div>
        </div>
      </div>
      <div className='team-member'>
        <div className='container text-center'>
          <div className='row team-support'>
            <div className='col'>
            <h4>Our Support &<span> Service Team</span></h4>
            <p>
              Laoreet suspendisse interdum consectetur libero id faucibus nisl tincidunt.
            </p>
            </div>
            <div className='col'>
              <button className='btn btn-danger'>Contect Them</button>
            </div>
          </div>
          <div className='row' style={{}}>
            <div className='col-sm-12 col-md-3'>
            {TeamMembers.map((project, index) => {
               return (
                 <TeamMember key={index} {...project} />
               )
             })}
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer></Footer>
      </div>
    </div>
  )
}

export default MyTeam
