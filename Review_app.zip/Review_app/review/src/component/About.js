// import { Link } from 'react-router-dom'
import '../assest/style.css/About.css'
import img1 from '../assest/img/Business woman photoshoot.jpeg'
import img2 from '../assest/img/using smart phone.jpeg'
import img3 from '../assest/img/img-sections-01-min.png'
import review1 from '../assest/img/review4.webp'
import review2 from '../assest/img/starbox.webp'
import Navbar from './Navbar'
import Footer from './Footer'

function About () {
  return (
    <div className='about'>
      <div className='header'>
        <div>
          <Navbar></Navbar>
        </div>
        <div className='nav-head text-center align-items-center'>
          <div className='star-icon'>
            <i class='fa-solid fa-star' style={{color: '#fbca18'}}></i>
            <h1>About Us</h1>
            <p>
              <span>Home -</span> About Us
            </p>
          </div>
        </div>
      </div>
      <div className='col'>
        <div className='about-blog1'>
          <div class='row space'>
            <div class='col-sm-12 col-s-12 col-md-12 col-lg-6 side-img-parent'>
              <div className='side-img'>
                <img src={img1} alt='' style={{height:'auto', width:'60%'}}></img>
              </div>
            </div>
            <div class='col-sm-12 col-s-12 col-md-12 col-lg-6 homepara about-blog-para'>
              <div>
                <img src={review1} alt='emoji' style={{height: '60px', width: '60px'}} />
              </div>
              <div style={{padding:'20px 0px 0px '}}>
                <h4>We Started In 2004 & Currently Have More Than
                  <span> 3 Million Members Worldwide</span>
                </h4>
                <p className='padding'>
                  Feugiat pretium nibh ipsum consequat nisl vel pretium lectus quam. Nulla at volutpat diam ut venenatis tellus in metus.
                </p>
              </div>
              <div className='row '>
                <div className='col-s-12 col-sm-12 col-md-12 col-lg-6 '>
                  <div className='row '>
                    <div className='col'>
                      <i class='fa-regular fa-star ' style={{color: '#ed071e'}}></i>
                      <i class='fa-regular fa-star ' style={{color: '#ed071e'}}></i>
                      <i class='fa-regular fa-star ' style={{color: '#ed071e'}}></i>
                    </div>
                  </div>
                  <div className='row'>
                    <div className='col'>
                      <i class='fa-regular fa-star ' style={{color: '#ed071e'}}></i>
                      <i class='fa-regular fa-hand-pointer fa-lg' style={{color: '#ed071e'}}></i>
                    </div>
                  </div>
                  <div className='row padding'>
                    <h6>Rate Products</h6>
                    <p>
                      Arcu cursus euismod quis viverra nibh cras pulvinar mattis.
                    </p>
                  </div>
                </div>
                <div className=' col-s-12 col-sm-12 col-md-12 col-lg-6'>
                  <div className='row'>
                    <div className='col'>
                      <i class='fa-regular fa-comment' style={{color: '#ed071e'}}></i>
                      <i class='fa-regular fa-user' style={{color: '#ed071e'}}></i>
                    </div>
                  </div>
                  <div className='row'>
                    <div className='col'>
                      <i class='fa-regular fa-user' style={{color: '#ed071e'}}></i>
                      <i class='fa-regular fa-comment fa-flip-both' style={{color: '#ed071e'}}></i>
                    </div>
                  </div>
                  <div className='row padding'>
                    <h6>Start Today</h6>
                    <p>
                      Arcu cursus euismod quis viverra nibh cras pulvinar mattis.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='row about-blog2'>
          <div class='row space'>
            <div class='col-sm-12 col-s-12 col-md-12 col-lg-6 about-blog-para homepara'>
              <div className='row'>
                <img src={review2} alt='emoji' style={{height: '60px', width: '70px'}} />
              </div>
              <div className='row' style={{padding:'20px 0px 0px'}}>
                <h4>Through Your Opinion We Inform Your Ideas For <span> Large Companies & Organization</span></h4>
                <p>
                  In pellentesque massa placerat duis ultricies lacus sed. Feugiat pretium nibh ipsum consequat nisl vel pretium lectus quam. Nulla at volutpat diam ut venenatis tellus
                  in metus.
                </p>
              </div>
              <div className='row'>
                <div className='padding'>
                <label>
                  Profitability
                </label>
                <div
                  className='progress'
                  role='progressbar'
                  aria-label='Danger example'
                  aria-valuenow='90'
                  aria-valuemin='0'
                  aria-valuemax='90'>
                  <div class='progress-bar bg-danger' style={{width: '70%'}}>
                    70%
                  </div>
                </div>
                </div>
                <div className='padding'>
                <label>
                  Satisfied Customers
                </label>
                <div
                  className='progress'
                  role='progressbar'
                  aria-label='Danger example'
                  aria-valuenow='100'
                  aria-valuemin='0'
                  aria-valuemax='100'>
                  <div class='progress-bar bg-danger' style={{width: '90%'}}>
                    90%
                  </div>
                </div>
                </div>
              </div>
            </div>
            <div class='col-sm-12 col-s-12 col-md-12 col-lg-6 side-img-parent'>
              <div className='side-img'>
                <img src={img2} alt='' style={{height:'auto', width:'80%'}} />
              </div>
            </div>
          </div>
        </div>
        <div className=' reviewus about-blog3'>
        <div className='row'>
          <div className=' col-sm-12 col-s-12 col-md-12 col-lg-6'>
            <div className='emoji-img side-img'>
              <img src={img3} alt='' style={{height:'auto', width:'70%'}} />
            </div>
          </div>
          <div className='col-sm-12 col-s-12 col-md-12 col-lg-6'>
            <div className='homepara'>
            <div className='emo1'>
              <img src={review1} alt='emoji' style={{height: '60px', width: '60px'}} />
            </div>
            <div className='emohead' style={{padding:'20px 0px 0px '}}>
              <h4>Opinions. We All Have Them, But They Are <span>Not Always Valued</span></h4>
              <div className='emopara'>
              <p className='para1'>
                Neque sodales ut etiam sit amet nisl purus. Mattis vulputate enim nulla aliquet. Laoreet suspendisse interdum consectetur libero id faucibus nisl tincidunt.
              </p>
              <p className='para2'>
                Gravida cum sociis natoque penatibus et magnis dis parturient. Suspendisse faucibus interdum posuere lorem ipsum dolor.
              </p>
              </div>
            </div>
            <div className='rewardbutton'>
              <button type='button' className='btn btn-danger' style={{width: '150px'}}>
                View Rewards
              </button>
            </div>
            </div>
          </div>
        </div>
      </div>
      </div>
      <Footer></Footer>
    </div>
  )
}

export default About
