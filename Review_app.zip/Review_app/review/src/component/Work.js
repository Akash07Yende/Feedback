import '../assest/style.css/work.css'
import Navbar from './Navbar'
import Footer from './Footer'
import img1 from '../assest/img/team-1-2.png'
import img2 from '../assest/img/team-1-3.png'
import img3 from '../assest/img/team-1-4.png'
import icon from '../assest/img/que_tick.webp'
import { WorkMember } from './WorkMembers'

function Work () {
  const WorkMembers = [
    {
      title: 'Contribute With Your Opinion',
      description: 'Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
      imgUrl: img1
    },
    {
      title: 'Rate A Product You Have Already Used',
      description: 'Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
      imgUrl: img2
    },
    {
      title: 'Collect Opinions & Get Your Choice Right',
      description: 'Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
      imgUrl: img3
    }
  ]

  return (
    <div className='how-it-work'>
      <div className='header text-center'>
        <div>
          <Navbar></Navbar>
        </div>
        <div className='nav-head'>
          <div className='star-icon'>
            <i class='fa-solid fa-star' style={{color: '#fbca18'}}></i>
            <h1>How Does It Work?</h1>
            <p>
              <span>Home -</span> How Does It Work?
            </p>
          </div>
        </div>
      </div>
      <div className='steps text-center'>
        <div className='col'>
          <div className='row'>
            <div className='icon'>
              <img src={icon} alt='icon' style={{height: '80px',width: '80px'}} />
            </div>
          </div>
          <div className='row work-steps'>
            <div>
              <h4>See How It Works In <span>3 Simple Steps</span></h4>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
              </p>
            </div>
          </div>
          <div className='row order'>
            <div className='col-sm-12 col-md-4'>
              <div className='steps-icon'>
                <i class='fa-solid fa-gear fa-2xl' style={{color: '#ffff'}}></i>
              </div>
              <div className='steps-way'>
                <h5>Sign Up For Free</h5>
                <p>
                  Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
                </p>
              </div>
            </div>
            <div className='col-sm-12 col-md-4'>
              <div className='steps-icon'>
                <i class='fa-regular fa-thumbs-up fa-2xl' style={{color: '#ffff'}}></i>
              </div>
              <div className='steps-way'>
                <h5>Participate In Surveys</h5>
                <p>
                  Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
                </p>
              </div>
            </div>
            <div className='col-sm-12 col-md-4'>
              <div className='steps-icon '>
                <i class='fa-solid fa-headset fa-2xl' style={{color: '#ffff'}}></i>
              </div>
              <div className='steps-way'>
                <h5>Earn Experiences</h5>
                <p>
                  Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
                </p>
              </div>
            </div>
          </div>
          <div className='row'>
            <div>
              <button type='button' class='btn btn-outline-danger'>
                I Want To Register
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className='row opinion text-center'>
        <div className='col'>
          <div className='row'>
            <div className='icon'>
              <img src={icon} alt='icon' style={{height: '80px',width: '80px'}} />
            </div>
          </div>
          <div className='row'>
            <div className='opinion-para'>
              <h3>Your Opinion Counts!</h3>
              <h3><span>Share Your Ideas & Collaborate</span></h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
              </p>
            </div>
          </div>
          <div className='row workmember'>
            {WorkMembers.map((project, index) => {
               return (
                 <WorkMember key={index} {...project} />
               )
             })}
          </div>
        </div>
      </div>
      <div>
        <Footer></Footer>
      </div>
    </div>
  )
}

export default Work
