import NavBar from './Navbar'
import emoji from '../assest/img/emoji3.png'
import Footer from './Footer'
import '../assest/style.css/Home.css'
import img3 from '../assest/img/img-sections-01-min.png'
import review1 from '../assest/img/review4.webp'

function Home () {

  // const [users, setUsers] = useState([])

  return (

    <div className='Home'>
      <div className='header text-center align-item-center'>
        <div className='home-navbar'>
          <NavBar/>
        </div>
        <div className='home-world'>
          <div className='col align-item-center text-center'>
            <h1><span>Sharing Your Opinion</span> By Rating Products & Brands Around The World</h1>
            <p>
              Est sit amet facilisis magna etiam. Ultricies lacus sed turpis tincidunt id aliquet risus. Accumsan tortor posuere ac ut. Pellentesque sit amet porttitor eget.
            </p>
          </div>
          <div>
            <button type='button' class='btn btn-danger'>
              Join Now
            </button>
          </div>
        </div>
      </div>
      <div className=' reviewus'>
        <div className='row'>
          <div className=' col-sm-12 col-s-12 col-md-12 col-lg-6'>
            <div className='emoji-img'>
              <img src={img3} alt='' style={{height: '300px', width: '300px'}} />
            </div>
          </div>
          <div className='col-sm-12 col-s-12 col-md-12 col-lg-6'>
            <div className='homepara'>
              <div className='emo1'>
                <img src={review1} alt='emoji' style={{height: '60px', width: '60px'}} />
              </div>
              <div className='emohead'>
                <h4>Opinions. We All Have Them, But They Are <span>Not Always Valued</span></h4>
                <div className='emopara'>
                  <p className='para1'>
                    Neque sodales ut etiam sit amet nisl purus. Mattis vulputate enim nulla aliquet. Laoreet suspendisse interdum consectetur libero id faucibus nisl tincidunt.
                  </p>
                  <p className='para2'>
                    Gravida cum sociis natoque penatibus et magnis dis parturient. Suspendisse faucibus interdum posuere lorem ipsum dolor.
                  </p>
                </div>
              </div>
              <div className='rewardbutton'>
                <button type='button' className='btn btn-danger' style={{width: '150px'}}>
                  View Rewards
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className='company-cards'>
        <div className=' container text-center'>
          <div className='emo2'>
            <div className=''>
              <img src={emoji} alt='emoji' style={{height: '60px', width: '60px'}} />
            </div>
            <div className='emo2para'>
              <h4>Start Reviewing These Products <span>Today</span></h4>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
              </p>
            </div>
            <div className=''>
              <div className=''>
                {/* <img src={imageUrl} alt='companyImage'/> */}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className=''>
        <Footer></Footer>
      </div>
    </div>
  )
}

export default Home
