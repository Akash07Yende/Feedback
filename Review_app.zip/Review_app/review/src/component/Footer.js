import thumbsUp from '../assest/img/Thumbs-up-img.png'
import '../assest/style.css/Footer.css'

function Footer () {
  return (
    <div className='footer-start'>
      <div className='section1'>
        <div className='row align-items-center'>
          <div className='col-sm-12 col-s-12 col-md-12 col-lg-4 thumb'>
            <div className='thumb-icon'>
              <img src={thumbsUp} alt='thumbsUp' className='center' style={{ height: '100px', width: '100px' }} />
            </div>
          </div>
          <div className='col-sm-12 col-s-12 col-md-12 col-lg-4 text-center padding'>
            <div className='footer-blog'>
              <h6>Just Take A Few Minutes And Find Out</h6>
              <h5><span>How You Can Help Someone Today!!</span></h5>
              <p>
                Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
              </p>
            </div>
          </div>
          <div className='col-sm-12 col-s-12 col-md-12 col-lg-4 text-center padding'>
            <button type='button' class='btn btn-danger'>
              Sign Up Now
            </button>
          </div>
        </div>
      </div>
      <footer id='footer' className='footer'>
        <div className='footer-content'>
          <div className='container'>
            <div className='row'>
              <div className='col-lg-3 col-md-6'>
                <div className='footer-info'>
                  <h3>EXPLORE</h3>
                  <p>
                    Wardha
                    <br /> 442 001, India
                    <br />
                    <br />
                    <strong>Phone:</strong> +91 8459576054
                    <br />
                    <strong>Email:</strong> team@reviewcompany.in
                    <br />
                  </p>
                </div>
              </div>
              <div className='col-lg-2 col-md-6 footer-links'>
                <h4>Useful Links</h4>
                <ul>
                  <li>
                    <i className='bi bi-chevron-right' />
                    <a href='/'>Home</a>
                  </li>
                  <li>
                    <i className='bi bi-chevron-right' />
                    <a href='About'>About us</a>
                  </li>
                  <li>
                    <i className='bi bi-chevron-right' />
                    <a href='Team'>Services</a>
                  </li>
                  <li>
                    <i className='bi bi-chevron-right' />
                    <a href='Work'>Terms of service</a>
                  </li>
                  <li>
                    <i className='bi bi-chevron-right' />
                    <a href>Privacy policy</a>
                  </li>
                </ul>
              </div>
              <div className='col-lg-3 col-md-6 footer-links'>
                <h4>Our Services</h4>
                <ul>
                  <li>
                    <i className='bi bi-chevron-right' />
                    <a href='#'>Web Design</a>
                  </li>
                  <li>
                    <i className='bi bi-chevron-right' />
                    <a href='#'>Web Development</a>
                  </li>
                  <li>
                    <i className='bi bi-chevron-right' />
                    <a href='#'>Product Management</a>
                  </li>
                  <li>
                    <i className='bi bi-chevron-right' />
                    <a href='#'>Marketing</a>
                  </li>
                  <li>
                    <i className='bi bi-chevron-right' />
                    <a href='#'>Graphic Design</a>
                  </li>
                </ul>
              </div>
              <div className='col-lg-4 col-md-6 footer-newsletter'>
                <h4>Our Newsletter</h4>
                <p>
                  Stay up-to-date with the latest industry trends, digital marketing insights, and exclusive offers by subscribing to our newsletter.
                </p>
                <form action method>
                  <input type='email' name='email' />
                  <input type='submit' defaultValue='Subscribe' />
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className='footer-legal text-center'>
          <div className='container d-flex flex-column flex-lg-row justify-content-center justify-content-lg-between align-items-center'>
            <div className='d-flex flex-column align-items-center align-items-lg-start'>
              <div className='copyright'>
                © Copyright
                {" "}
                <strong><span>Review</span></strong> . All Rights Reserved
              </div>
              <div className='credits'>
                Designed and Developed by
                {" "}
                <a href='https://reviewcompany.in/'>Review</a>
              </div>
            </div>
            <div className='social-links order-first order-lg-last mb-3 mb-lg-0'>
              <a href='#' className='twitter'><i class='fa-brands fa-twitter'></i></a>
              <a href='#' className='facebook'><i class='fa-brands fa-facebook'></i></a>
              <a href='#' className='instagram'><i class='fa-brands fa-instagram'></i></a>
              <a href='#' className='google-plus'><i class='fa-brands fa-pinterest'></i></a>
              <a href='#' className='linkedin'><i class='fa-brands fa-linkedin'></i></a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default Footer
