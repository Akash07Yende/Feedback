

export function TeamMember ({title, description, imgUrl}) {
    return (
      <div className="row members" >
        <div className="col-sm-12 col-md-4 col-lg-4">
          <div className='card proj-imgbx' style={{width: '18rem'}}>
        <img src={imgUrl} className='card-img-top' alt='...' />
        <div className='card-body'>
          <h6 className='card-title'>{title}</h6>
          <p className='card-text'>
            {description}
          </p>
          <a href='#' className='card-link'>Read More</a>
        </div>
      </div>
      </div>
      </div>
    )
  }