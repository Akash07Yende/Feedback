import Navbar from './Navbar'
import emoji from '../assest/img/emoji1.png'
import '../assest/style.css/addcompany.css'
import { useState } from 'react'
import {getDatabase, ref, set} from 'firebase/database'
import { ref as storageReference, uploadBytes, getDownloadURL, getStorage} from 'firebase/storage';
import { app } from './Firebaseconfig';

import Footer from './Footer'


function AddCompany () {

  const [registerCompany, setRegisterCompany] = useState({
    id : null,
    CompanyName: '',
    state: '',
    address:'',
    message: '',
    img: null, // Use null as the initial value for the file
  });
  // const [showLogin, setShowLogin] = useState(false);

  const database = getDatabase(app);
  const storage = getStorage(app)  



  const RegisterCompany = async (e) => {
    e.preventDefault()
    
    // Check if the user is authenticated
    

    try {
   
      const { id, CompanyName, State, address, message, img } = registerCompany;

      // Upload image to Firebase Storage
      const storageRef = storageReference(storage, `company_images/${CompanyName}`);
      await uploadBytes(storageRef, img);

      // Get the download URL of the uploaded image
      const imgUrl = await getDownloadURL(storageRef);

     
      await set(ref(database, `allcompany/${CompanyName}/aboutCompany`), {
        id: Math.random()*10000,
        CompanyName,
        State,
        address,
        message,
        img: imgUrl, // Store the image URL
      });

      alert('Successfully added');
    } catch (error) {
      console.error('Error:', error);
      alert(`Error: ${error}`);
    }
  };

  const ChangeHandler = (e) => {
    if (e.target.name === 'img') {
      // Handle file input separately
      setRegisterCompany({
        ...registerCompany,
        img: e.target.files[0], // Use the first selected file
      });
    } else {
      setRegisterCompany({
        ...registerCompany,
        [e.target.name]: e.target.value,
      });
    }
  };
  return (
    <div className='add-company-start'>
      <div className='header'>
        <div>
          <Navbar></Navbar>
        </div>
        <div className='nav-head text-center align-items-center'>
          <div className='star-icon'>
            <i className='fa-solid fa-star' style={{color: '#fbca18'}}></i>
            <h1>Add Company</h1>
            <p>
              <span>Home -</span> Add Company
            </p>
          </div>
        </div>
      </div>
      <section id="company" className="company">
        <div className="container text-center" style={{paddingBottom:'20px'}}>
          <div className="section-header">
            <div className=''>
              <img src={emoji} alt='emoji' style={{height:'60px', width:'60px'}} />
            </div>
            <h2>Learn More About Opiniun & <span> Schedule A Demo</span></h2>
            <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
            </p>
          </div>
        </div>
        <div className="container">
          <div className="row formcenter">
            <div className="col-lg-8">
              <form id="contactForm" className="php-email-form" method='POST' onSubmit={RegisterCompany}>
                <div className="row">
                  <div className="col-md-12 form-group">
                    <input
                      type="file"
                      name="imgUrl"
                      onChange={ChangeHandler}
                      className="form-control"
                      id="name"
                      placeholder="Your Image"
                    />
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-6 form-group">
                    <input
                      type="text"
                      name="CompanyName"
                      value={registerCompany.CompanyName}
                      onChange={ChangeHandler}
                      className="form-control"
                      id="contact"
                      placeholder="Compant Name"
                    />
                  </div>
                  <div className="col-md-6 form-group mt-3 mt-md-0">
                    <input
                      type="text"
                      className="form-control"
                      name="state"
                      value={registerCompany.state}
                      onChange={ChangeHandler}
                      id="email"
                      placeholder="State"
                    />
                  </div>
                </div>
                <div className="form-group mt-3">
                  <input
                    type="text"
                    className="form-control"
                    name="address"
                    value={registerCompany.address}
                    onChange={ChangeHandler}
                    id="subject"
                    placeholder="Address"
                  />
                </div>
                <div className="form-group mt-3">
                  <textarea
                    className="form-control"
                    id="message"
                    name="message"
                    value={registerCompany.message}
                    onChange={ChangeHandler}
                    placeholder="Message"
                  />
                </div>
                <div className="text-center">
                  <button type="submit" >Send Message</button>
                </div>
              </form>
            </div>
            {/* End Contact Form */}
          </div>
        </div>
      </section>
      <div className='footersection'>
        <Footer/>
      </div>
    </div>
  )
}

export default AddCompany
