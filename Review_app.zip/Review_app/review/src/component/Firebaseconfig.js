// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD8n5uYEPnx24RSr7HyoQ2iG_gd8KrMAiU",
  authDomain: "loki-17318.firebaseapp.com",
  databaseURL: "https://loki-17318-default-rtdb.firebaseio.com",
  projectId: "loki-17318",
  storageBucket: "loki-17318.appspot.com",
  messagingSenderId: "460184242625",
  appId: "1:460184242625:web:7d41d72b2c1ee4b54e0740"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);