import Button from 'react-bootstrap/Button'
import Container from 'react-bootstrap/Container'
import Form from 'react-bootstrap/Form'
import Nav from 'react-bootstrap/Nav'
import Navbar from 'react-bootstrap/Navbar'
import NavDropdown from 'react-bootstrap/NavDropdown'
import { useState, useEffect } from 'react'
import { HashLink } from 'react-router-hash-link'
import { Link } from 'react-router-dom'

import logo from '../assest/img/explore-high.png'
import '../App.css'
import AboutUs from './About'
import AddCompany from './AddCompany'

function NavBar () {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    }

    window.addEventListener('scroll', onScroll)

    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <Navbar expand='md' className={scrolled ? 'scrolled' : ''}>
      <Container>
        <Navbar.Brand href='/'>
          <img src={logo} alt='Logo' style={{height:'24px',width:'120px'}} />
        </Navbar.Brand>
        <Navbar.Toggle aria-controls='basic-navbar-nav'>
          <span className='navbar-toggler-icon'></span>
        </Navbar.Toggle>
        <Navbar.Collapse id='basic-navbar-nav'>
          <Nav className='ms-auto'>
            <Nav.Link href='/'>
              Home
            </Nav.Link>
            <Nav.Link href='About'>
              About Us
            </Nav.Link>
            <NavDropdown title='Pages' id='basic-nav-dropdown'>
              <NavDropdown.Item href='AddCompany'>
                AddCompany
              </NavDropdown.Item>
              <NavDropdown.Item href='Team'>
                Team
              </NavDropdown.Item>
              <NavDropdown.Item href='Work'>
                Work
              </NavDropdown.Item>
              <NavDropdown.Item href='#'>
                Separated link
              </NavDropdown.Item>
            </NavDropdown>
            <Nav.Link href="Contact">Contact Us</Nav.Link>

          </Nav>
          <span className='navbar-text'><HashLink to='#connect'> <button variant='danger' className='vvd'> <span>Sign Up</span> </button>
          </HashLink>
          </span>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default NavBar
