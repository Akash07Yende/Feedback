// import { Link } from 'react-router-dom';
// import { useState } from 'react';
// import logo from './assest/img/explore-high.png'

// import RatingImg from './assest/img/Man_hand_giving_five_star_rating_cartoon_illustration_character.png';
// import img1 from './assest/img/man_laptop.jpeg'
// import img2 from './assest/img/Photo by fauxels on Pexels.jpeg'
// import img3 from './assest/img/Emoji-bg.png'
// import img4 from './assest/img/mall-svgrepo-com.svg'
// import ContactLogo from './assest/img/Mobile user-cuate.png'
// // import logo from './assest/img/review-high.png'
// import './assest/style.css/contact.css'

// function Landing() {
//   const [user, setUser] = useState({
//     CompanyName: '',
//     Location: '',
//     Image: '',
//   })

//   let name, value;

//   const getData = (event) => {

//     name = event.target.name;

//     value = event.target.value;

//     setUser({ ...user, [name]: value })

//   }

//   const SendData = (e) => {

//     const { CompanyName, Location, Image } = user

//     e.preventDefault();

//     if (CompanyName && Location && Image) {

//       const response = fetch('https://review-a5ef8-default-rtdb.firebaseio.com/Company-Info.json',

//         {
//           method: 'POST',

//           headers: {

//             "Content-Type": "application/json"

//           },

//           body: JSON.stringify({

//             CompanyName,
//             Location,
//             Image,
//           })
//         })
//       if (response) {
//         return setUser({
//           CompanyName: "",
//           Location: "",
//           Image: "",
//         })
//       }
//     }
//     else {
//       alert("Please Fill The Data");
//     }
//   }
//   return (
//     <div className='head'>
//       <div className='Navbar'>
//         <nav className="navbar navbar-expand-lg" style={{ backgroundColor: 'bisque' }} data-bs-theme="dark">
//           <div className="container-fluid">
//             <a className="navbar-brand" href="#">
//               <img src={logo} alt="Bootstrap" width="100" height="24" />
//             </a>
//             <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
//               <span className="navbar-toggler-icon" />
//             </button>
//             <div className="collapse navbar-collapse" id="navbarSupportedContent" >
//               <ul className="navbar-nav me-auto mb-2 mb-lg-0" >
//                 <li className="nav-item" >
//                   <a className="nav-link active" aria-current="page" href="#" >Home</a>
//                 </li>
//                 <li className="nav-item">
//                   <a className="nav-link" href="#">About Us</a>
//                 </li>
//                 <li className="nav-item">
//                   <a className="nav-link" href="#" role="button">
//                     Review
//                   </a>
//                 </li>
//                 <li className="nav-item">
//                   <a className="nav-link">Contact</a>
//                 </li>
//               </ul>
//               <form className="d-flex" role="search">
//                 <Link to='/SignIn'>
//                   <button className="btn btn-danger" type="submit">Sign In</button>
//                 </Link>
//               </form>
//             </div>
//           </div>
//         </nav>
//       </div>
//       <div className='nav-head'>
//         <div className='star-icon'>
//           <i class="fa-solid fa-star fa-xl"></i>
//           <h1>Research For Company</h1>
//           <p><span>Home - </span>Research For Company</p>
//         </div>
//       </div>

//       <div className='nav-head2'>
//         <div className='rating-img'>
//           <img src={RatingImg} alt='' width="200" height="100" />
//         </div>
//         <div className='head2-pag'>
//           <p className='f-pag'>Give Us Your Feedback</p>
//           <p>sit amet, consectetur adipisicing elit. Corporis eos omnis facilis qui, placeat sapiente illo saepe rerum dolorum.</p>
//         </div>
//       </div>

//       <div className='main'>
//         <div class="main-box">
//           <div className='Box1'>Content</div>
//           <div className='Box1'>Content</div>
//           <div className='Box1'>Content</div>
//           <div className='Box1'>Content</div>
//         </div>

//         <div class="main-box">
//           <div className='Box1'>Content</div>
//           <div className='Box1'>Content</div>
//           <div className='Box1'>Content</div>
//           <div className='Box1'>Content</div>
//         </div>
//       </div>
//       <div className='mid-section'>
//         <div className='section1'>
//           <img src={img2} alt='About Us' />
//         </div>
//         <div className='section2'>

//           <div className='section2-img'>
//             <img src={img4} />
//           </div>

//           <div className='section2-start'>
//             <h1>We Started In 2004 & Currently Have more Than</h1>
//             <p style={{ color: 'orangered' }}>3 Millions Members Worldwide</p>

//           </div>
//           <div className='section2-end'>
//             <p>
//               Lorem ipsum, dolor sit amet consectetur adipisicing elit.
//               Assumenda inventore est, quia reiciendis, optio vitae ad placeat aspernatur,
//               facere voluptatum omnis ex doloremque suscipit qui et dolor sed quos ipsam.
//             </p>
//           </div>

//         </div>
//       </div>
//       <div className='mid-section1'>

//         <div className='section2'>

//           <div className='section2-img'>
//             <img src={img4} />
//           </div>

//           <div className='section2-start'>
//             <h1>Through Your Opinion We Inform Your Ideas For</h1>
//             <p style={{ color: 'orangered' }}>Large Companies & Organization</p>
//           </div>
//           <div className='section2-end'>
//             <p>
//               Lorem ipsum, dolor sit amet consectetur adipisicing elit.
//               Assumenda inventore est, quia reiciendis, optio vitae ad placeat aspernatur,
//               facere voluptatum omnis ex doloremque suscipit qui et dolor sed quos ipsam.
//             </p>
//           </div>

//         </div>
//         <div className='section1'>
//           <img src={img1} alt='About Us' />
//         </div>
//       </div>
//       <div className='mid-section'>
//         <div className='section1'>
//           <img src={img3} alt='About Us' />
//         </div>
//         <div className='section2'>

//           <div className='section2-img'>
//             <img src={img4} />
//           </div>

//           <div className='section2-start'>
//             <h1>Opinions. We All Have Them, But They Are<span> Not Always Valued</span></h1>
//           </div>
//           <div className='section2-end'>
//             <p>
//               Lorem ipsum, dolor sit amet consectetur adipisicing elit.
//               Assumenda inventore est, quia reiciendis, optio vitae ad placeat aspernatur,
//               facere voluptatum omnis ex doloremque suscipit qui et dolor sed quos ipsam.
//             </p>
//           </div>

//         </div>
//       </div>
//       <div className='page-section'>
//         <div className='section1'>
//           <img src={img2} alt='About Us' />
//         </div>
//         <div className='section2'>

//           <div className='section2-img'>
//             <img src={img4} />
//           </div>

//           <div className='section2-start'>
//             <h1>We Started In 2004 & Currently Have more Than</h1>
//             <p style={{ color: 'orangered' }}>3 Millions Members Worldwide</p>

//           </div>
//           <div className='section2-end'>
//             <p>
//               Lorem ipsum, dolor sit amet consectetur adipisicing elit.
//               Assumenda inventore est, quia reiciendis, optio vitae ad placeat aspernatur,
//               facere voluptatum omnis ex doloremque suscipit qui et dolor sed quos ipsam.
//             </p>
//           </div>

//         </div>
//       </div>
//       <div className='add-company'>
//         <div className='heading'>
//           <h1>
//             You can Add Company Which Are Not In Our List.
//           </h1>
//         </div>
//         <div className='input-field'>
//           <div class="input-group">
//             <span class="input-group-text">Company Name</span>
//             <input type="text" aria-label="First name" class="form-control" name='CompanyName' value={user.CompanyName} onChange={getData} />
//           </div>
//           <div class="input-group">
//             <span class="input-group-text">Location</span>
//             <input type="text" aria-label="First name" class="form-control" name='Location' value={user.Location} onChange={getData} />
//           </div>
//           <div class="input-group">
//             <span class="input-group-text">Image/Logo</span>
//             <input type="file" aria-label="First name" class="form-control" name='Image' value={user.Image} onChange={getData} />
//           </div>
//           <div>
//             <button type="button" class="btn btn-danger" onClick={SendData}>Danger</button>
//           </div>
//         </div>
//       </div>
//       <div className='section-head'>
//         <div class="container input">
//           <div class=" grid col">
//             <div class="row g-col-4" >
//               <h1>Contact Us</h1>
//             </div>
//             <div class="row">
//               <input type="text" className="form-control" placeholder="First name" aria-label="First name" name='FirstName' value={user.FirstName} onChange={getData} />
//             </div>
//             <div class="row">
//               <input type="text" className="form-control" placeholder="Last name" aria-label="Last name" name='LastName' value={user.LastName} onChange={getData} />
//             </div>
//             <div class="row">
//               <input type="email" className="form-control" placeholder="Email" aria-label="Email" name='Email' value={user.Email} onChange={getData} />
//             </div>
//             <div class="row">
//               <textarea class="form-control" placeholder="Message" aria-label="With textarea" name='Message' value={user.Message} onChange={getData} />
//             </div>
//             <div class="row">
//               <button type="button" className="btn btn-danger">Send Message</button>
//             </div>
//           </div>
//         </div>

//         <div className='section-img'>
//           <img src={ContactLogo} className="img-fluid" alt="..." />
//         </div>
//       </div>
//     </div>
//   )
// }

// export default Landing;